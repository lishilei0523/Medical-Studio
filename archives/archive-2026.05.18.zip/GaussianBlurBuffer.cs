﻿using MedicalSharp.Inspiration.Resources;
using System;

namespace MedicalSharp.Inspiration.Algorithms
{
    /// <summary>
    /// 3D高斯滤波算法
    /// </summary>
    /// <remarks>ClBuffer版</remarks>
    public sealed class GaussianBlurBuffer : IDisposable
    {
        #region # 字段及构造器

        /// <summary>
        /// 释放标识
        /// </summary>
        private bool _disposed;

        /// <summary>
        /// OpenCL上下文
        /// </summary>
        private readonly ClContext _clContext;

        /// <summary>
        /// OpenCL程序
        /// </summary>
        private readonly ClProgram _program;

        /// <summary>
        /// OpenCL内核
        /// </summary>
        private readonly ClKernel _kernel;

        /// <summary>
        /// 创建3D高斯滤波算法构造器
        /// </summary>
        /// <param name="clContext">OpenCL上下文</param>
        public GaussianBlurBuffer(ClContext clContext)
        {
            this._clContext = clContext;
            this._program = ClProgram.FromFile(this._clContext, "Resources/Kernels/gaussian_blur_3d_buffer.cl");
            this._kernel = this._program.CreateKernel("gaussian_blur_3d");
        }

        #endregion

        #region # 属性

        #region 只读属性 - OpenCL程序 —— ClProgram Program
        /// <summary>
        /// 只读属性 - OpenCL程序
        /// </summary>
        public ClProgram Program
        {
            get => this._program;
        }
        #endregion

        #region 只读属性 - OpenCL内核 —— ClKernel Kernel
        /// <summary>
        /// 只读属性 - OpenCL内核
        /// </summary>
        public ClKernel Kernel
        {
            get => this._kernel;
        }
        #endregion

        #endregion

        #region # 方法

        #region 执行高斯滤波 —— void Execute(ClBuffer inputBuffer, ClBuffer outputBuffer...
        /// <summary>
        /// 执行高斯滤波
        /// </summary>
        /// <param name="inputBuffer">输入缓冲区</param>
        /// <param name="outputBuffer">输出缓冲区</param>
        /// <param name="width">宽度</param>
        /// <param name="height">高度</param>
        /// <param name="depth">深度</param>
        /// <param name="kernelSize">核矩阵尺寸</param>
        /// <param name="sigma">标准差</param>
        /// <remarks>核矩阵尺寸必须为奇数(3、5、7等)，标准差常用(0.5~2.5)</remarks>
        public void Execute(ClBuffer inputBuffer, ClBuffer outputBuffer, int width, int height, int depth, int kernelSize = 3, float sigma = 1.0f)
        {
            this._kernel.SetBufferKernelArg(0, inputBuffer);
            this._kernel.SetBufferKernelArg(1, outputBuffer);
            this._kernel.SetKernelArg(2, width);
            this._kernel.SetKernelArg(3, height);
            this._kernel.SetKernelArg(4, depth);
            this._kernel.SetKernelArg(5, kernelSize);
            this._kernel.SetKernelArg(6, sigma);
            this._kernel.Enqueue3D(this._clContext.CommandQueue, (uint)width, (uint)height, (uint)depth);
        }
        #endregion

        #region 执行高斯滤波（PBO） —— void ExecutePBO(ClBuffer inputBuffer, ClBuffer outputBuffer...
        /// <summary>
        /// 执行高斯滤波（PBO）
        /// </summary>
        /// <param name="inputBuffer">从读PBO共享的ClBuffer</param>
        /// <param name="outputBuffer">从写PBO共享的ClBuffer</param>
        /// <param name="width">宽度</param>
        /// <param name="height">高度</param>
        /// <param name="depth">深度</param>
        /// <param name="kernelSize">核矩阵尺寸</param>
        /// <param name="sigma">标准差</param>
        public void ExecutePBO(ClBuffer inputBuffer, ClBuffer outputBuffer, int width, int height, int depth, int kernelSize = 3, float sigma = 1.0f)
        {
            //接管两个PBO
            inputBuffer.AcquireForCL(this._clContext.CommandQueue);
            outputBuffer.AcquireForCL(this._clContext.CommandQueue);

            //执行滤波
            this.Execute(inputBuffer, outputBuffer, width, height, depth, kernelSize, sigma);
            this._clContext.Finish();

            //归还两个PBO
            inputBuffer.ReleaseToGL(this._clContext.CommandQueue);
            outputBuffer.ReleaseToGL(this._clContext.CommandQueue);
        }
        #endregion

        #region 释放资源 —— void Dispose()
        /// <summary>
        /// 释放资源
        /// </summary>
        public void Dispose()
        {
            if (this._disposed)
            {
                return;
            }

            this._kernel?.Dispose();
            this._program?.Dispose();
            this._disposed = true;
        }
        #endregion 

        #endregion
    }
}
