﻿using MedicalSharp.Engine.Renderables;
using MedicalSharp.Engine.Resources;
using MedicalSharp.Primitives.Models;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace MedicalSharp.Engine.Algorithms
{
    /// <summary>
    /// 同步算法
    /// </summary>
    public static class SyncAlgorithms
    {
        #region # 同步预览数据GPU->CPU —— static void SyncPreviewDataFromGpu(VolumeData volumeData...
        /// <summary>
        /// 同步预览数据GPU->CPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="previewTexture">预览纹理</param>
        /// <repreviews>将GPU预览纹理数据回读到CPU端的VolumeData.PreviewData</repreviews>
        public static void SyncPreviewDataFromGpu(VolumeData volumeData, Texture3D previewTexture)
        {
            #region # 验证

            if (volumeData.PreviewData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU预览数据未分配！");
            }
            if (!volumeData.TryBeginPreviewGpuToCpu())
            {
                throw new InvalidOperationException($"预览数据正在同步中，当前状态: \"{volumeData.PreviewSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = previewTexture.Width;
                int height = previewTexture.Height;
                int depth = previewTexture.Depth;
                int bufferSize = width * height * depth;

                //读取3D纹理到PBO
                using ReadPixelBuffer3D readBuffer = ReadPixelBuffer3D.CreatePreview16(width, height, depth);
                readBuffer.ReadTexture3D(previewTexture, true);

                //获取数据（阻塞等待）
                byte[] data = readBuffer.GetCpuBuffer();

                //复制到非托管内存
                if (data != null && data.Length == bufferSize)
                {
                    Marshal.Copy(data, 0, volumeData.PreviewData, bufferSize);
                }
            }
            finally
            {
                volumeData.EndPreviewSync();
            }
        }
        #endregion

        #region # 同步预览数据CPU->GPU —— static void SyncPreviewDataToGpu(VolumeData volumeData...
        /// <summary>
        /// 同步预览数据CPU->GPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="previewTexture">预览纹理</param>
        /// <repreviews>将CPU端VolumeData.PreviewData上传到GPU预览纹理</repreviews>
        public static void SyncPreviewDataToGpu(VolumeData volumeData, Texture3D previewTexture)
        {
            #region # 验证

            if (volumeData.PreviewData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU预览数据未分配！");
            }
            if (!volumeData.TryBeginPreviewCpuToGpu())
            {
                throw new InvalidOperationException($"预览数据正在同步中，当前状态: \"{volumeData.PreviewSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = previewTexture.Width;
                int height = previewTexture.Height;
                int depth = previewTexture.Depth;
                using WritePixelBuffer3D writeBuffer = WritePixelBuffer3D.CreatePreview16(width, height, depth);

                //上传到PBO
                writeBuffer.UploadData(volumeData.PreviewData);

                //上传到纹理
                writeBuffer.UploadToTexture(previewTexture, true);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex);
            }
            finally
            {
                volumeData.EndPreviewSync();
            }
        }
        #endregion

        #region # 同步预览数据GPU->CPU —— static void SyncPreviewDataFromGpu(this VolumeRenderable renderable)
        /// <summary>
        /// 同步预览数据GPU->CPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <repreviews>将GPU预览纹理数据回读到CPU端的VolumeData.PreviewData</repreviews>
        public static void SyncPreviewDataFromGpu(this VolumeRenderable renderable)
        {
            SyncPreviewDataFromGpu(renderable.VolumeData, renderable.PreviewTexture);
        }
        #endregion

        #region # 同步预览数据CPU->GPU —— static void SyncPreviewDataToGpu(this VolumeRenderable renderable)
        /// <summary>
        /// 同步预览数据CPU->GPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <repreviews>将CPU端VolumeData.PreviewData上传到GPU预览纹理</repreviews>
        public static void SyncPreviewDataToGpu(this VolumeRenderable renderable)
        {
            SyncPreviewDataToGpu(renderable.VolumeData, renderable.PreviewTexture);
        }
        #endregion

        #region # 同步标记数据GPU->CPU —— static void SyncMarkDataFromGpu(VolumeData volumeData...
        /// <summary>
        /// 同步标记数据GPU->CPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="markTexture">标记纹理</param>
        /// <remarks>将GPU标记纹理数据回读到CPU端的VolumeData.MarkData</remarks>
        public static void SyncMarkDataFromGpu(VolumeData volumeData, Texture3D markTexture)
        {
            #region # 验证

            if (volumeData.MarkData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU标记数据未分配！");
            }
            if (!volumeData.TryBeginMarkGpuToCpu())
            {
                throw new InvalidOperationException($"标记数据正在同步中，当前状态: \"{volumeData.MarkSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = markTexture.Width;
                int height = markTexture.Height;
                int depth = markTexture.Depth;
                int bufferSize = width * height * depth;

                //读取3D纹理到PBO
                using ReadPixelBuffer3D readBuffer = ReadPixelBuffer3D.CreateMark8(width, height, depth);
                readBuffer.ReadTexture3D(markTexture, true);

                //获取数据（阻塞等待）
                byte[] data = readBuffer.GetCpuBuffer();

                //复制到非托管内存
                if (data != null && data.Length == bufferSize)
                {
                    Marshal.Copy(data, 0, volumeData.MarkData, bufferSize);
                }
            }
            finally
            {
                volumeData.EndMarkSync();
            }
        }
        #endregion

        #region # 同步标记数据CPU->GPU —— static void SyncMarkDataToGpu(VolumeData volumeData...
        /// <summary>
        /// 同步标记数据CPU->GPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="markTexture">标记纹理</param>
        /// <remarks>将CPU端VolumeData.MarkData上传到GPU标记纹理</remarks>
        public static void SyncMarkDataToGpu(VolumeData volumeData, Texture3D markTexture)
        {
            #region # 验证

            if (volumeData.MarkData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU标记数据未分配！");
            }
            if (!volumeData.TryBeginMarkCpuToGpu())
            {
                throw new InvalidOperationException($"标记数据正在同步中，当前状态: \"{volumeData.MarkSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = markTexture.Width;
                int height = markTexture.Height;
                int depth = markTexture.Depth;
                using WritePixelBuffer3D writeBuffer = WritePixelBuffer3D.CreateMark8(width, height, depth);

                //上传到PBO
                writeBuffer.UploadData(volumeData.MarkData);

                //上传到纹理
                writeBuffer.UploadToTexture(markTexture, true);
            }
            finally
            {
                volumeData.EndMarkSync();
            }
        }
        #endregion

        #region # 同步标记数据GPU->CPU —— static void SyncMarkDataFromGpu(this VolumeRenderable renderable)
        /// <summary>
        /// 同步标记数据GPU->CPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <remarks>将GPU标记纹理数据回读到CPU端的VolumeData.MarkData</remarks>
        public static void SyncMarkDataFromGpu(this VolumeRenderable renderable)
        {
            SyncMarkDataFromGpu(renderable.VolumeData, renderable.MarkTexture);
        }
        #endregion

        #region # 同步标记数据CPU->GPU —— static void SyncMarkDataToGpu(this VolumeRenderable renderable)
        /// <summary>
        /// 同步标记数据CPU->GPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <remarks>将CPU端VolumeData.MarkData上传到GPU标记纹理</remarks>
        public static void SyncMarkDataToGpu(this VolumeRenderable renderable)
        {
            SyncMarkDataToGpu(renderable.VolumeData, renderable.MarkTexture);
        }
        #endregion

        #region # 异步同步预览数据GPU->CPU —— static async Task SyncPreviewDataFromGpuAsync(VolumeData volumeData...
        /// <summary>
        /// 异步同步预览数据GPU->CPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="previewTexture">预览纹理</param>
        /// <repreviews>将GPU预览纹理数据回读到CPU端的VolumeData.PreviewData</repreviews>
        public static async Task SyncPreviewDataFromGpuAsync(VolumeData volumeData, Texture3D previewTexture)
        {
            #region # 验证

            if (volumeData.PreviewData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU预览数据未分配！");
            }
            if (!volumeData.TryBeginPreviewGpuToCpu())
            {
                throw new InvalidOperationException($"预览数据正在同步中，当前状态: \"{volumeData.PreviewSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = previewTexture.Width;
                int height = previewTexture.Height;
                int depth = previewTexture.Depth;
                int bufferSize = width * height * depth;

                //异步读取3D纹理
                byte[] data = await Task.Run(() =>
                {
                    using ReadPixelBuffer3D readBuffer = ReadPixelBuffer3D.CreatePreview16(width, height, depth);
                    readBuffer.ReadTexture3D(previewTexture, true);
                    return readBuffer.GetCpuBuffer();
                });

                //复制到非托管内存
                if (data != null && data.Length == bufferSize)
                {
                    Marshal.Copy(data, 0, volumeData.PreviewData, bufferSize);
                }
            }
            finally
            {
                volumeData.EndPreviewSync();
            }
        }
        #endregion

        #region # 异步同步预览数据CPU->GPU —— static async Task SyncPreviewDataToGpuAsync(this VolumeRenderable...
        /// <summary>
        /// 异步同步预览数据CPU->GPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="previewTexture">预览纹理</param>
        /// <repreviews>将CPU端VolumeData.PreviewData上传到GPU预览纹理</repreviews>
        public static async Task SyncPreviewDataToGpuAsync(VolumeData volumeData, Texture3D previewTexture)
        {
            #region # 验证

            if (volumeData.PreviewData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU预览数据未分配！");
            }
            if (!volumeData.TryBeginPreviewCpuToGpu())
            {
                throw new InvalidOperationException($"预览数据正在同步中，当前状态: \"{volumeData.PreviewSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = previewTexture.Width;
                int height = previewTexture.Height;
                int depth = previewTexture.Depth;

                await Task.Run(() =>
                {
                    using WritePixelBuffer3D writeBuffer = WritePixelBuffer3D.CreatePreview16(width, height, depth);

                    //上传到PBO
                    writeBuffer.UploadData(volumeData.PreviewData);

                    //上传到纹理
                    writeBuffer.UploadToTexture(previewTexture, true);
                });
            }
            finally
            {
                volumeData.EndPreviewSync();
            }
        }
        #endregion

        #region # 异步同步预览数据GPU->CPU —— static async Task SyncPreviewDataFromGpuAsync(this VolumeRenderable...
        /// <summary>
        /// 异步同步预览数据GPU->CPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <repreviews>将GPU预览纹理数据回读到CPU端的VolumeData.PreviewData</repreviews>
        public static async Task SyncPreviewDataFromGpuAsync(this VolumeRenderable renderable)
        {
            await SyncPreviewDataFromGpuAsync(renderable.VolumeData, renderable.PreviewTexture);
        }
        #endregion

        #region # 异步同步预览数据CPU->GPU —— static async Task SyncPreviewDataToGpuAsync(this VolumeRenderable...
        /// <summary>
        /// 异步同步预览数据CPU->GPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <repreviews>将CPU端VolumeData.PreviewData上传到GPU预览纹理</repreviews>
        public static async Task SyncPreviewDataToGpuAsync(this VolumeRenderable renderable)
        {
            await SyncPreviewDataToGpuAsync(renderable.VolumeData, renderable.PreviewTexture);
        }
        #endregion

        #region # 异步同步标记数据GPU->CPU —— static async Task SyncMarkDataFromGpuAsync(VolumeData volumeData...
        /// <summary>
        /// 异步同步标记数据GPU->CPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="markTexture">标记纹理</param>
        /// <remarks>将GPU标记纹理数据回读到CPU端的VolumeData.MarkData</remarks>
        public static async Task SyncMarkDataFromGpuAsync(VolumeData volumeData, Texture3D markTexture)
        {
            #region # 验证

            if (volumeData.MarkData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU标记数据未分配！");
            }
            if (!volumeData.TryBeginMarkGpuToCpu())
            {
                throw new InvalidOperationException($"标记数据正在同步中，当前状态: \"{volumeData.MarkSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = markTexture.Width;
                int height = markTexture.Height;
                int depth = markTexture.Depth;
                int bufferSize = width * height * depth;

                //异步读取3D纹理
                byte[] data = await Task.Run(() =>
                {
                    using ReadPixelBuffer3D readBuffer = ReadPixelBuffer3D.CreateMark8(width, height, depth);
                    readBuffer.ReadTexture3D(markTexture, true);
                    return readBuffer.GetCpuBuffer();
                });

                //复制到非托管内存
                if (data != null && data.Length == bufferSize)
                {
                    Marshal.Copy(data, 0, volumeData.MarkData, bufferSize);
                }
            }
            finally
            {
                volumeData.EndMarkSync();
            }
        }
        #endregion

        #region # 异步同步标记数据CPU->GPU —— static async Task SyncMarkDataToGpuAsync(VolumeData volumeData...
        /// <summary>
        /// 异步同步标记数据CPU->GPU
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="markTexture">标记纹理</param>
        /// <remarks>将CPU端VolumeData.MarkData上传到GPU标记纹理</remarks>
        public static async Task SyncMarkDataToGpuAsync(VolumeData volumeData, Texture3D markTexture)
        {
            #region # 验证

            if (volumeData.MarkData == IntPtr.Zero)
            {
                throw new InvalidOperationException("CPU标记数据未分配！");
            }
            if (!volumeData.TryBeginMarkCpuToGpu())
            {
                throw new InvalidOperationException($"标记数据正在同步中，当前状态: \"{volumeData.MarkSyncStatus}\"");
            }

            #endregion

            try
            {
                int width = markTexture.Width;
                int height = markTexture.Height;
                int depth = markTexture.Depth;

                await Task.Run(() =>
                {
                    using WritePixelBuffer3D writeBuffer = WritePixelBuffer3D.CreateMark8(width, height, depth);

                    //上传到PBO
                    writeBuffer.UploadData(volumeData.MarkData);

                    //上传到纹理
                    writeBuffer.UploadToTexture(markTexture, true);
                });
            }
            finally
            {
                volumeData.EndMarkSync();
            }
        }
        #endregion

        #region # 异步同步标记数据GPU->CPU —— static async Task SyncMarkDataFromGpuAsync(this VolumeRenderable...
        /// <summary>
        /// 异步同步标记数据GPU->CPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <remarks>将GPU标记纹理数据回读到CPU端的VolumeData.MarkData</remarks>
        public static async Task SyncMarkDataFromGpuAsync(this VolumeRenderable renderable)
        {
            await SyncMarkDataFromGpuAsync(renderable.VolumeData, renderable.MarkTexture);
        }
        #endregion

        #region # 异步同步标记数据CPU->GPU —— static async Task SyncMarkDataToGpuAsync(this VolumeRenderable...
        /// <summary>
        /// 异步同步标记数据CPU->GPU
        /// </summary>
        /// <param name="renderable">体积渲染对象</param>
        /// <remarks>将CPU端VolumeData.MarkData上传到GPU标记纹理</remarks>
        public static async Task SyncMarkDataToGpuAsync(this VolumeRenderable renderable)
        {
            await SyncMarkDataToGpuAsync(renderable.VolumeData, renderable.MarkTexture);
        }
        #endregion
    }
}
