﻿using itk.simple;
using MedicalSharp.Insight.Models;
using MedicalSharp.Primitives.Models;
using OpenTK.Mathematics;
using System;
using System.Diagnostics;

namespace MedicalSharp.Insight.Algorithms
{
    /// <summary>
    /// 统计算法
    /// </summary>
    public static class AnalyseAlgorithms
    {
        #region # 适用矩形统计 —— static StatisticResult ApplyRectangleAnalyse(this VolumeData volumeData...
        /// <summary>
        /// 适用矩形统计
        /// </summary>
        /// <param name="volumeData">体积数据</param>
        /// <param name="mmCenter">矩形中心（毫米空间）</param>
        /// <param name="uAxis">U轴方向</param>
        /// <param name="vAxis">V轴方向</param>
        /// <param name="mmWidth">矩形宽度（mm）</param>
        /// <param name="mmHeight">矩形高度（mm）</param>
        /// <param name="markValue">标记值</param>
        /// <returns>统计结果</returns>
        public static StatisticResult ApplyRectangleAnalyse(this VolumeData volumeData, Vector3 mmCenter, Vector3 uAxis, Vector3 vAxis, float mmWidth, float mmHeight, byte? markValue)
        {
            #region # 验证

            if (mmWidth <= 0 || mmHeight <= 0)
            {
                return default;
            }
            if (volumeData is not SitkVolumeData sitkVolumeData)
            {
                return default;
            }

            #endregion

            //计算法向量
            Vector3 normal = Vector3.Normalize(Vector3.Cross(uAxis, vAxis));

            //获取体素间距
            Vector3 spacing = volumeData.Metadata.Spacing;

            //输出图像间距（U/V方向上的体素投影长度）
            float outputSpacingU = Math.Abs(Vector3.Dot(uAxis, new Vector3(spacing.X, 0, 0))) +
                                   Math.Abs(Vector3.Dot(uAxis, new Vector3(0, spacing.Y, 0))) +
                                   Math.Abs(Vector3.Dot(uAxis, new Vector3(0, 0, spacing.Z)));
            float outputSpacingV = Math.Abs(Vector3.Dot(vAxis, new Vector3(spacing.X, 0, 0))) +
                                   Math.Abs(Vector3.Dot(vAxis, new Vector3(0, spacing.Y, 0))) +
                                   Math.Abs(Vector3.Dot(vAxis, new Vector3(0, 0, spacing.Z)));

            //输出图像尺寸
            int outputSizeU = Math.Max(1, (int)MathF.Round(mmWidth / outputSpacingU));
            int outputSizeV = Math.Max(1, (int)MathF.Round(mmHeight / outputSpacingV));

            //输出图像原点（矩形角点）
            Vector3 origin = mmCenter - uAxis * mmWidth / 2 - vAxis * mmHeight / 2;

            //构建SimpleITK方向矩阵（3x3，列优先）
            double[] direction =
            [
                uAxis.X, uAxis.Y, uAxis.Z,
                vAxis.X, vAxis.Y, vAxis.Z,
                normal.X, normal.Y, normal.Z
            ];

            //预览图与标记图
            Image previewImage = sitkVolumeData.SitkPreviewImage;
            Image markImage = sitkVolumeData.SitkMarkImage;

            var origin2 = previewImage.GetOrigin();
            Trace.WriteLine($"{origin2[0]},{origin2[1]},{origin2[2]}");

            //重采样
            using VectorUInt32 outputSize = new VectorUInt32([(uint)outputSizeU, (uint)outputSizeV, 1]);
            using VectorDouble outputOrigin = new VectorDouble([origin.X, origin.Y, origin.Z]);
            using Transform outputTransform = new Transform(3, TransformEnum.sitkIdentity);
            using VectorDouble outputSpacing = new VectorDouble([outputSpacingU, outputSpacingV, 1.0]);
            using VectorDouble outputDirection = new VectorDouble(direction);
            using Image resampledPreview = SimpleITK.Resample(previewImage, outputSize, outputTransform, InterpolatorEnum.sitkLinear, outputOrigin, outputSpacing, outputDirection);

            Trace.WriteLine($"Size: {resampledPreview.GetSize()[0]} x {resampledPreview.GetSize()[1]} x {resampledPreview.GetSize()[2]}");
            Trace.WriteLine($"Origin: {resampledPreview.GetOrigin()[0]}, {resampledPreview.GetOrigin()[1]}, {resampledPreview.GetOrigin()[2]}");
            Trace.WriteLine($"Spacing: {resampledPreview.GetSpacing()[0]}, {resampledPreview.GetSpacing()[1]}, {resampledPreview.GetSpacing()[2]}");
            Trace.WriteLine($"Direction: {string.Join(", ", resampledPreview.GetDirection())}");


            //统计
            float minHU;
            float maxHU;
            float averageHU;
            float stdDevHU;
            int voxelsCount;
            if (markValue.HasValue)
            {
                using Image resampledMark = SimpleITK.Resample(markImage, outputSize, outputTransform, InterpolatorEnum.sitkNearestNeighbor, outputOrigin, outputSpacing, outputDirection);
                using LabelStatisticsImageFilter labelStats = new LabelStatisticsImageFilter();
                labelStats.Execute(resampledPreview, resampledMark);
                minHU = (float)labelStats.GetMinimum(markValue.Value);
                maxHU = (float)labelStats.GetMaximum(markValue.Value);
                averageHU = (float)labelStats.GetMean(markValue.Value);
                stdDevHU = (float)labelStats.GetSigma(markValue.Value);
                voxelsCount = (int)labelStats.GetCount(markValue.Value);
            }
            else
            {
                using StatisticsImageFilter stats = new StatisticsImageFilter();
                stats.Execute(resampledPreview);
                minHU = (float)stats.GetMinimum();
                maxHU = (float)stats.GetMaximum();
                averageHU = (float)stats.GetMean();
                stdDevHU = (float)stats.GetSigma();
                voxelsCount = outputSizeU * outputSizeV;
            }

            StatisticResult result = new StatisticResult
            {
                MinHU = minHU,
                MaxHU = maxHU,
                AverageHU = averageHU,
                StdDevHU = stdDevHU,
                VoxelsCount = voxelsCount
            };

            return result;
        }
        #endregion
    }
}
